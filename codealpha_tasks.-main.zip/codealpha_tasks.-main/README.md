# codealpha_tasks.
Task 1: Student Grade System.

Task 2: Online Quiz Platform.

task 3: Trravel Itinerary Planner.
